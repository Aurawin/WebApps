importScripts(
  '/core/app/worker/base.js'
);

this.onerror=function(e){

};
this.onmessage=function(e){

};
